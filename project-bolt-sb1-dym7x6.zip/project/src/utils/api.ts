import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export interface BookingData {
  clientName: string;
  clientEmail: string;
  sessionType: string;
  date: string;
  time: string;
}

export const bookSession = async (bookingData: BookingData) => {
  try {
    const response = await axios.post(`${API_URL}/api/bookings`, bookingData);
    return response.data;
  } catch (error) {
    console.error('Booking error:', error);
    throw error;
  }
};