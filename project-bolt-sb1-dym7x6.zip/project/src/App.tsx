import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Music from './components/Music';
import PressKit from './components/Tour';
import Appointments from './components/Appointments';
import Contact from './components/Contact';

function App() {
  return (
    <div className="bg-black">
      <Navbar />
      <Hero />
      <Music />
      <PressKit />
      <Appointments />
      <Contact />
    </div>
  );
}

export default App;