import { useState } from 'react';
import { Calendar, Clock, Music2 } from 'lucide-react';
import { bookSession } from '../utils/api';
import type { BookingData } from '../utils/api';

const timeSlots = [
  '10:00 AM', '11:00 AM', '1:00 PM', 
  '2:00 PM', '3:00 PM', '4:00 PM'
];

const sessionTypes = [
  { id: 'recording', name: 'Recording Session', duration: '2 hours', price: '$150' },
  { id: 'mixing', name: 'Mixing Session', duration: '3 hours', price: '$200' },
  { id: 'mastering', name: 'Mastering', duration: '1 hour', price: '$100' }
];

export default function Appointments() {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [selectedSession, setSelectedSession] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [isBooking, setIsBooking] = useState(false);

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime || !selectedSession || !clientName || !clientEmail) {
      alert('Please fill in all fields');
      return;
    }

    setIsBooking(true);

    try {
      const bookingData: BookingData = {
        clientName,
        clientEmail,
        sessionType: selectedSession,
        date: selectedDate,
        time: selectedTime,
      };

      await bookSession(bookingData);
      alert('Session booked successfully! Check your email for confirmation.');
      resetForm();
    } catch (error) {
      console.error('Booking error:', error);
      alert('Error booking session. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  const resetForm = () => {
    setSelectedDate('');
    setSelectedTime('');
    setSelectedSession('');
    setClientName('');
    setClientEmail('');
  };

  return (
    <section id="appointments" className="py-24 bg-gradient-to-b from-black to-primary-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Book a Session</h2>
          <p className="text-gray-300">Schedule your next recording, mixing, or mastering session</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Client Information */}
          <div className="bg-black/50 backdrop-blur-sm rounded-lg p-6 border border-primary/20">
            <h3 className="text-xl font-semibold text-white mb-4">Client Information</h3>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Your Name"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full px-4 py-2 bg-black text-white rounded-lg border border-primary/20 focus:outline-none focus:border-primary"
              />
              <input
                type="email"
                placeholder="Your Email"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                className="w-full px-4 py-2 bg-black text-white rounded-lg border border-primary/20 focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          {/* Session Types */}
          <div className="bg-black/50 backdrop-blur-sm rounded-lg p-6 space-y-4 border border-primary/20">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
              <Music2 className="h-5 w-5 mr-2 text-primary" />
              Select Session Type
            </h3>
            <div className="space-y-3">
              {sessionTypes.map((session) => (
                <label
                  key={session.id}
                  className={`block p-4 rounded-lg border-2 transition-colors cursor-pointer
                    ${selectedSession === session.id 
                      ? 'border-primary bg-primary/20' 
                      : 'border-primary/20 hover:border-primary'}`}
                >
                  <input
                    type="radio"
                    name="session"
                    value={session.id}
                    className="hidden"
                    onChange={(e) => setSelectedSession(e.target.value)}
                  />
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="block text-white font-medium">{session.name}</span>
                      <span className="text-sm text-gray-400">{session.duration}</span>
                    </div>
                    <span className="text-primary font-semibold">{session.price}</span>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Date and Time Selection */}
          <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Date Selection */}
            <div className="bg-black/50 backdrop-blur-sm rounded-lg p-6 border border-primary/20">
              <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-primary" />
                Select Date
              </h3>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-4 py-2 bg-black text-white rounded-lg border border-primary/20 focus:outline-none focus:border-primary"
                min={new Date().toISOString().split('T')[0]}
              />
            </div>

            {/* Time Selection */}
            <div className="bg-black/50 backdrop-blur-sm rounded-lg p-6 border border-primary/20">
              <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
                <Clock className="h-5 w-5 mr-2 text-primary" />
                Select Time
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`px-4 py-2 rounded-lg transition-colors border
                      ${selectedTime === time
                        ? 'bg-primary text-white border-primary'
                        : 'bg-black text-gray-300 border-primary/20 hover:border-primary'}`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Book Button */}
        <div className="mt-12 text-center">
          <button
            onClick={handleBooking}
            disabled={!selectedDate || !selectedTime || !selectedSession || !clientName || !clientEmail || isBooking}
            className={`px-8 py-3 rounded-full text-white font-semibold transition-colors
              ${selectedDate && selectedTime && selectedSession && clientName && clientEmail && !isBooking
                ? 'bg-primary hover:bg-primary-dark'
                : 'bg-gray-800 cursor-not-allowed'}`}
          >
            {isBooking ? 'Booking...' : 'Book Session'}
          </button>
        </div>
      </div>
    </section>
  );
}