import { Mail, Instagram, Twitter, Youtube } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Connect With Me</h2>
          <p className="text-gray-400">Stay updated with the latest news and releases</p>
        </div>

        <div className="max-w-xl mx-auto">
          <form className="space-y-6">
            <div>
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full px-4 py-3 bg-black text-white rounded-lg border border-primary/20 focus:outline-none focus:border-primary"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-primary hover:bg-primary-dark text-white py-3 rounded-lg transition-colors"
            >
              Subscribe to Newsletter
            </button>
          </form>

          <div className="mt-12 flex justify-center space-x-8">
            <a href="#" className="text-gray-400 hover:text-primary transition-colors">
              <Instagram className="h-6 w-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-primary transition-colors">
              <Twitter className="h-6 w-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-primary transition-colors">
              <Youtube className="h-6 w-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-primary transition-colors">
              <Mail className="h-6 w-6" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}