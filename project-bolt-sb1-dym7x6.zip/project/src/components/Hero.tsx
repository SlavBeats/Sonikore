import { Play } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen relative flex items-center justify-center">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-primary-dark to-black" />
      </div>
      
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          Sonikore Studios
        </h1>
        <p className="text-xl md:text-2xl text-gray-200 mb-8">
          Where Your Sound Comes Alive
        </p>
        <button className="bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-full flex items-center justify-center space-x-2 mx-auto transition-colors">
          <Play className="h-5 w-5" />
          <span>Book a Session</span>
        </button>
      </div>
    </section>
  );
}