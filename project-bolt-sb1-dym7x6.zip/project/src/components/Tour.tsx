import { Download, ExternalLink } from 'lucide-react';

const pressKit = {
  studioSpaces: [
    {
      name: "Main Studio A - Control Room",
      description: "Professional grade mixing and mastering environment"
    },
    {
      name: "Live Room",
      description: "Acoustically treated space for live recordings"
    },
    {
      name: "Vocal Booth",
      description: "Isolated space for pristine vocal recordings"
    }
  ],
  team: [
    {
      name: "Alex Rivers",
      role: "Lead Producer & Studio Owner"
    },
    {
      name: "Sarah Chen",
      role: "Mixing Engineer"
    },
    {
      name: "Marcus Thompson",
      role: "Mastering Engineer"
    }
  ],
  achievements: [
    "10+ Platinum Records",
    "Grammy-Nominated Productions",
    "State-of-the-art SSL Console",
    "Vintage Analog Equipment"
  ]
};

export default function PressKit() {
  return (
    <section id="tour" className="py-24 bg-gradient-to-b from-black to-primary-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Press Kit</h2>
          <p className="text-gray-300">Experience the excellence of Sonikore Studios</p>
          <button className="mt-6 bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-full inline-flex items-center transition-colors">
            <Download className="h-5 w-5 mr-2" />
            Download Full Press Kit
          </button>
        </div>

        {/* Studio Facilities */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-white mb-8 text-center">Our Facilities</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pressKit.studioSpaces.map((space, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg bg-primary/10 h-64 border border-primary/20">
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end">
                  <div className="p-4">
                    <h4 className="text-white font-medium mb-2">{space.name}</h4>
                    <p className="text-gray-300 text-sm">{space.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Team */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-white mb-8 text-center">Meet The Team</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pressKit.team.map((member, index) => (
              <div key={index} className="bg-black/50 backdrop-blur-sm rounded-lg overflow-hidden border border-primary/20">
                <div className="h-64 bg-primary/10"></div>
                <div className="p-6">
                  <h4 className="text-xl font-semibold text-white mb-2">{member.name}</h4>
                  <p className="text-primary">{member.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-black/50 backdrop-blur-sm rounded-lg p-8 border border-primary/20">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Studio Achievements</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pressKit.achievements.map((achievement, index) => (
              <div
                key={index}
                className="text-center p-4 border border-primary/30 rounded-lg bg-primary/10"
              >
                <p className="text-white">{achievement}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Press Contact */}
        <div className="mt-16 text-center">
          <p className="text-gray-300 mb-4">For press inquiries and media assets:</p>
          <a
            href="mailto:press@sonikorestudios.com"
            className="text-primary hover:text-accent inline-flex items-center transition-colors"
          >
            press@sonikorestudios.com
            <ExternalLink className="h-4 w-4 ml-1" />
          </a>
        </div>
      </div>
    </section>
  );
}