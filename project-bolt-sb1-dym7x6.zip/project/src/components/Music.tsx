import { Play, Share2, Download } from 'lucide-react';

const beats = [
  {
    title: "Midnight Groove",
    genre: "Hip Hop",
    bpm: 95,
    duration: "2:45",
    price: "$299",
    license: "Exclusive"
  },
  {
    title: "Urban Soul",
    genre: "R&B",
    bpm: 85,
    duration: "3:12",
    price: "$199",
    license: "Basic Lease"
  },
  {
    title: "Trap Kingdom",
    genre: "Trap",
    bpm: 140,
    duration: "2:58",
    price: "$349",
    license: "Exclusive"
  }
];

export default function Music() {
  return (
    <section id="music" className="py-16 bg-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white mb-2 text-center">Beat Portfolio</h2>
        <p className="text-gray-400 text-center mb-8">Premium beats available for licensing</p>
        
        <div className="space-y-4">
          {beats.map((beat, index) => (
            <div key={index} className="bg-zinc-900/50 rounded-lg overflow-hidden group border border-primary/20 hover:border-primary transition-colors">
              <div className="flex items-center p-4">
                {/* Play Button */}
                <div className="mr-4">
                  <button className="bg-primary/10 hover:bg-primary/20 rounded-full p-3 transition-colors">
                    <Play className="h-5 w-5 text-primary" />
                  </button>
                </div>

                {/* Beat Info */}
                <div className="flex-grow grid grid-cols-2 md:grid-cols-6 gap-4 items-center">
                  <div className="md:col-span-2">
                    <h3 className="text-lg font-semibold text-white">{beat.title}</h3>
                    <p className="text-sm text-gray-400">{beat.genre}</p>
                  </div>
                  
                  <div className="text-sm text-gray-400">
                    <span className="block text-white">{beat.bpm} BPM</span>
                    <span>{beat.duration}</span>
                  </div>
                  
                  <div className="text-sm text-gray-400">
                    <span className="block text-white">{beat.license}</span>
                    <span className="text-primary font-semibold">{beat.price}</span>
                  </div>

                  {/* Action Buttons */}
                  <div className="md:col-span-2 flex justify-end space-x-4">
                    <button className="text-primary hover:text-accent transition-colors">
                      <Download className="h-5 w-5" />
                    </button>
                    <button className="text-primary hover:text-accent transition-colors">
                      <Share2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <button className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-full text-sm transition-colors">
            View Full Catalog
          </button>
        </div>
      </div>
    </section>
  );
}